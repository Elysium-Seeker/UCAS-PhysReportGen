"""
AI 报告生成器模块
支持多种 AI 后端（OpenAI API、本地 Ollama 等）
"""

import os
import json
import base64
import requests
import io
from PIL import Image
from typing import Dict, List, Optional, Any
from abc import ABC, abstractmethod


def resize_image_for_api(image_path, max_size=1024):
    """
    调整图片大小以适应 API 限制并提高速度
    """
    try:
        with Image.open(image_path) as img:
            # 转换为 RGB (防止 RGBA 问题)
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            width, height = img.size
            if width > max_size or height > max_size:
                ratio = min(max_size / width, max_size / height)
                new_size = (int(width * ratio), int(height * ratio))
                img = img.resize(new_size, Image.Resampling.LANCZOS)
            
            # 转为 JPEG 字节流
            buffer = io.BytesIO()
            img.save(buffer, format="JPEG", quality=85)
            return buffer.getvalue()
    except Exception as e:
        print(f"图片处理出错: {e}, 将使用原始图片")
        with open(image_path, "rb") as f:
            return f.read()


class AIBackend(ABC):
    """AI 后端抽象基类"""
    
    @abstractmethod
    def generate(self, prompt: str, images: List[str] = None) -> str:
        """生成文本"""
        pass


class OpenAIBackend(AIBackend):
    """OpenAI API 后端"""
    
    def __init__(self, api_key: str, api_url: str = "https://api.openai.com/v1/chat/completions", model: str = "gpt-4"):
        self.api_key = api_key
        self.api_url = api_url
        self.model = model
    
    def generate(self, prompt: str, images: List[str] = None) -> str:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        messages = [{"role": "user", "content": []}]
        
        # 添加文本
        messages[0]["content"].append({
            "type": "text",
            "text": prompt
        })
        
        # 添加图片（如果有）
        if images:
            for img_path in images:
                if os.path.exists(img_path):
                    # 使用压缩后的图片数据
                    img_data_bytes = resize_image_for_api(img_path)
                    img_data = base64.b64encode(img_data_bytes).decode()
                    
                    messages[0]["content"].append({
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{img_data}"
                        }
                    })
        
        data = {
            "model": self.model,
            "messages": messages,
            "max_tokens": 4096
        }
        
        # 增加超时时间到 300 秒
        response = requests.post(self.api_url, headers=headers, json=data, timeout=300)
        response.raise_for_status()
        
        result = response.json()
        return result["choices"][0]["message"]["content"]


class OllamaBackend(AIBackend):
    """本地 Ollama 后端"""
    
    def __init__(self, base_url: str = "http://localhost:11434", model: str = "llama3"):
        self.base_url = base_url
        self.model = model
    
    def generate(self, prompt: str, images: List[str] = None) -> str:
        url = f"{self.base_url}/api/generate"
        
        data = {
            "model": self.model,
            "prompt": prompt,
            "stream": False
        }
        
        # Ollama 的多模态支持
        if images:
            data["images"] = []
            for img_path in images:
                if os.path.exists(img_path):
                    img_data_bytes = resize_image_for_api(img_path)
                    img_data = base64.b64encode(img_data_bytes).decode()
                    data["images"].append(img_data)
        
        response = requests.post(url, json=data, timeout=300)
        response.raise_for_status()
        
        result = response.json()
        return result["response"]


class MockBackend(AIBackend):
    """模拟后端（用于测试）"""
    
    def generate(self, prompt: str, images: List[str] = None) -> str:
        return """
\\section{实验目的}
\\begin{enumerate}
    \\item 请根据实验指导书填写实验目的
\\end{enumerate}

\\section{实验器材}
请根据实验指导书填写实验器材

\\section{实验原理}
请根据实验指导书填写实验原理

\\section{实验步骤}
\\begin{enumerate}
    \\item 请根据实验指导书填写实验步骤
\\end{enumerate}

\\section{实验结果与数据处理}
请根据数据记录表填写实验数据

\\section{思考题}
\\begin{enumerate}
    \\item 思考题1
    
    答: 请填写答案
\\end{enumerate}

\\section{总结}
请填写实验总结
"""


class ReportGenerator:
    """实验报告生成器"""
    
    SYSTEM_PROMPT = """你是一个专业的物理实验报告撰写助手。你将根据提供的实验指导书和数据记录表，生成规范的 LaTeX 格式实验报告。"""
    
    def __init__(self, backend: AIBackend = None):
        """
        初始化生成器
        
        Args:
            backend: AI 后端实例，None 则使用模拟后端
        """
        self.backend = backend or MockBackend()
    
    def generate_report_content(self,
                                experiment_guide: str = None,
                                data_sheet_images: List[str] = None,
                                additional_requirements: str = None) -> str:
        """
        生成完整的报告内容（分步生成机制）
        
        Args:
            experiment_guide: 实验指导书内容（文本）
            data_sheet_images: 数据记录表图片路径列表
            additional_requirements: 额外要求
            
        Returns:
            合成的完整 LaTeX 报告内容
        """
        print("开始分步生成报告...")
        
        # 1. 生成基础部分 (目的、器材、原理、步骤)
        print("Step 1: 生成基础部分...")
        part1_prompt = self._build_part1_prompt(experiment_guide, additional_requirements)
        part1_content = self.backend.generate(part1_prompt)
        print("Step 1 完成")
        
        # 2. 生成数据处理部分 (结果与数据处理) - 需要传图
        print("Step 2: 生成数据处理部分...")
        part2_prompt = self._build_part2_prompt(part1_content, additional_requirements)
        part2_content = self.backend.generate(part2_prompt, data_sheet_images)
        print("Step 2 完成")
        
        # 3. 生成分析与总结 (思考题、总结)
        print("Step 3: 生成分析与总结...")
        # 将前两部分作为上下文，确保连贯性
        context = f"{part1_content}\n{part2_content}"
        part3_prompt = self._build_part3_prompt(context, additional_requirements)
        part3_content = self.backend.generate(part3_prompt)
        print("Step 3 完成")
        
        # 合成最终内容
        full_content = f"{part1_content}\n\n{part2_content}\n\n{part3_content}"
        
        return full_content

    def _build_part1_prompt(self, guide, requirements):
        return f"""{self.SYSTEM_PROMPT}

请生成报告的第一部分：
1. \\section{{实验目的}}
2. \\section{{实验器材}}
3. \\section{{实验原理}}
4. \\section{{实验步骤}}

## 实验指导书内容：
{guide if guide else "无"}

## 额外要求：
{requirements if requirements else "无"}

请只返回这 4 个 section 的 LaTeX 内容。
"""

    def _build_part2_prompt(self, previous_context, requirements):
        # 截取前文的一部分作为上下文（避免太长）
        context_preview = previous_context[:1000] + "..." + previous_context[-1000:] if len(previous_context) > 2000 else previous_context
        
        return f"""{self.SYSTEM_PROMPT}

已生成部分内容：
{context_preview}

现在请生成报告的第二部分：
5. \\section{{实验结果与数据处理}}

此部分非常重要，请根据附带的 **数据记录表图片** 仔细识别数据。
- 必须创建 LaTeX 表格 (table 环境) 填入所有数据。
- 进行必要的数据处理和计算。
- 既然是视觉识别，请尽量完整提取表格内容。

## 额外要求：
{requirements if requirements else "无"}

请只返回 \\section{{实验结果与数据处理}} 及其内容的 LaTeX 代码。
"""

    def _build_part3_prompt(self, previous_context, requirements):
        # 同样提供上下文
        context_preview = previous_context[:2000] + "..." + previous_context[-1000:] if len(previous_context) > 3000 else previous_context

        return f"""{self.SYSTEM_PROMPT}

已生成报告的前面部分：
{context_preview}

现在请生成报告的最后部分：
6. \\section{{思考题}} (如果指导书中有，请回答；如果没有，生成 2 个相关的扩展思考题并回答)
7. \\section{{总结}} (总结实验结果、误差分析、心得体会)

## 额外要求：
{requirements if requirements else "无"}

请只返回这两部分的 LaTeX 代码。
"""

    def modify_report_content(self, 
                             current_content: str,
                             modification_request: str) -> str:
        """
        根据用户要求修改报告内容
        """
        prompt = f"""请根据以下要求修改实验报告：

## 当前报告内容：
```latex
{current_content[:15000]}
```

## 修改要求：
{modification_request}

请返回修改后的完整 LaTeX 内容。
"""
        return self.backend.generate(prompt)


def create_generator(backend_type: str = "mock", **kwargs) -> ReportGenerator:
    """
    创建报告生成器
    
    Args:
        backend_type: 后端类型 ("openai", "ollama", "mock")
        **kwargs: 后端参数
        
    Returns:
        ReportGenerator 实例
    """
    if backend_type == "openai":
        backend = OpenAIBackend(
            api_key=kwargs.get("api_key", ""),
            api_url=kwargs.get("api_url", "https://api.openai.com/v1/chat/completions"),
            model=kwargs.get("model", "gpt-4")
        )
    elif backend_type == "ollama":
        backend = OllamaBackend(
            base_url=kwargs.get("base_url", "http://localhost:11434"),
            model=kwargs.get("model", "llama3")
        )
    else:
        backend = MockBackend()
    
    return ReportGenerator(backend)
